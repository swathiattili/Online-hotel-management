package com.code.userservice.entity;

public enum ERole {
   ROLE_OWNER,ROLE_MANAGER,ROLE_RECEPTIONIST

}
